TikZoom safe source export
Excluded: .env, TLS private keys, data/, bots_storage/, .venv/, logs/, backups/, generated legacy miniapp builds.

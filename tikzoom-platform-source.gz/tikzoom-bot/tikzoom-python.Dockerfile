FROM docker.io/library/python:3.12-slim

ENV PYTHONUNBUFFERED=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    PIP_DISABLE_PIP_VERSION_CHECK=1 \
    PIP_NO_CACHE_DIR=1

RUN python -m pip install --no-cache-dir \
    aiohttp \
    aiosqlite \
    aiogram \
    python-dotenv \
    requests \
    pyTelegramBotAPI \
    telethon \
    kvsqlite \
    flask \
    beautifulsoup4 \
    PyYAML \
    Pillow

WORKDIR /workspace

CMD ["python", "--version"]
